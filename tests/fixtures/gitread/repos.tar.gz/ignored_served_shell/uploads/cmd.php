<?php // a harmless fixture file
