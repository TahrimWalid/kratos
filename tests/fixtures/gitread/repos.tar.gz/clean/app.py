print('hi')
